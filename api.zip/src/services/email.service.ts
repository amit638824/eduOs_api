import {
  adminPasswordResetMailTemplate,
  contactFormMailTemplate,
  emailVerificationOtpMailTemplate,
  examAssignmentMailTemplate,
  forgetPasswordMailTemplate,
  organizationActionMailTemplate,
  organizationCredentialsMailTemplate,
  paymentConfirmationMailTemplate,
  userCredentialsMailTemplate,
  welcomeMailTemplate,
  type OrganizationActionType,
} from '../templates/emailTemplates.js';
import * as orgService from './organization.service.js';
import { env, bccEmails, isSmtpConfigured, frontendUrl } from '../config/env.js';
import nodemailer from 'nodemailer';

let transporter: nodemailer.Transporter | null = null;


function getTransporter(): nodemailer.Transporter | null {
  if (!isSmtpConfigured) return null;

  if (!transporter) {
    transporter = nodemailer.createTransport({
      host: env.SMTP_HOST,
      port: env.SMTP_PORT,
      secure: false, // STARTTLS on port 587
      requireTLS: true,
      auth: {
        user: env.SMTP_USER,
        pass: env.SMTP_PASS,
      },
    });
  }

  return transporter;
}

export interface SendEmailInput {
  to: string | string[];
  subject: string;
  html: string;
  text?: string;
}

export async function sendEmail(input: SendEmailInput): Promise<boolean> {
  const mailer = getTransporter();
  if (!mailer) {
    console.warn('[email] SMTP not configured — skipping send to', input.to);
    return false;
  }

  const from = env.SMTP_FROM ?? env.SMTP_USER ?? 'noreply@edutech.com';

  await mailer.sendMail({
    from: `"${env.APP_NAME}" <${from}>`,
    to: input.to,
    bcc: bccEmails.length > 0 ? bccEmails : undefined,
    subject: input.subject,
    html: input.html,
    text: input.text,
  });

  return true;
}

export async function sendPasswordResetEmail(email: string, resetToken: string): Promise<boolean> {
  const resetUrl = frontendUrl(`/reset-password?token=${encodeURIComponent(resetToken)}`);
  return sendEmail({
    to: email,
    subject: `Reset your ${env.APP_NAME} password`,
    html: forgetPasswordMailTemplate({ hyperText: resetUrl }),
    text: `Reset your password: ${resetUrl}\nExpires in 1 hour.`,
  });
}

export async function sendAdminPasswordResetEmail(
  email: string,
  userName: string,
  resetToken: string,
): Promise<boolean> {
  const resetLink = frontendUrl(`/reset-password?token=${encodeURIComponent(resetToken)}`);
  return sendEmail({
    to: email,
    subject: `Set a new password for your ${env.APP_NAME} account`,
    html: adminPasswordResetMailTemplate({ userName, resetLink }),
    text: `Your password was reset by an administrator. Set a new password: ${resetLink}`,
  });
}

export async function sendOtpEmail(email: string, code: string, purpose: string): Promise<boolean> {
  return sendEmail({
    to: email,
    subject: `Your ${env.APP_NAME} verification code`,
    html: emailVerificationOtpMailTemplate({ hyperText: code, purpose }),
    text: `Your OTP for ${purpose} is ${code}. Valid for 10 minutes.`,
  });
}

export async function sendPaymentConfirmationEmail(
  email: string,
  amount: number,
  currency: string,
  paymentId: string,
): Promise<boolean> {
  return sendEmail({
    to: email,
    subject: `Payment received — ${env.APP_NAME}`,
    html: paymentConfirmationMailTemplate({ amount, currency, paymentId }),
    text: `Payment of ${currency} ${amount} received. Ref: ${paymentId}`,
  });
}

export async function sendWelcomeEmail(email: string, firstName: string): Promise<boolean> {
  const loginUrl = frontendUrl('/login');
  return sendEmail({
    to: email,
    subject: `Welcome to ${env.APP_NAME}`,
    html: welcomeMailTemplate({ firstName, loginUrl }),
    text: `Welcome to ${env.APP_NAME}. Login at ${loginUrl}`,
  });
}

export async function sendExamAssignmentEmail(input: {
  to: string;
  studentName: string;
  examName: string;
  scheduledDate?: string | null;
  scheduledTime?: string | null;
  durationMinutes?: number | null;
  status?: string | null;
}): Promise<boolean> {
  const dashboardUrl = frontendUrl('/dashboard');

  return sendEmail({
    to: input.to,
    subject: `Exam assigned: ${input.examName}`,
    html: examAssignmentMailTemplate({
      studentName: input.studentName,
      examName: input.examName,
      scheduledDate: input.scheduledDate,
      scheduledTime: input.scheduledTime,
      durationMinutes: input.durationMinutes,
      status: input.status,
      dashboardUrl,
    }),
    text: [
      `Hello ${input.studentName},`,
      '',
      `An exam has been assigned to you: ${input.examName}`,
      input.scheduledDate ? `Scheduled date: ${input.scheduledDate}` : null,
      input.scheduledTime ? `Scheduled time: ${input.scheduledTime}` : null,
      input.durationMinutes ? `Duration: ${input.durationMinutes} minutes` : null,
      input.status ? `Status: ${input.status}` : null,
      '',
      `Open your dashboard: ${dashboardUrl}`,
    ]
      .filter(Boolean)
      .join('\n'),
  });
}

/** Faculty / student / org user credentials after admin creates the account */
export async function sendUserCredentialsEmail(input: {
  to: string;
  firstName: string;
  role: 'student' | 'teacher' | 'org_admin' | 'staff';
  loginEmail: string;
  enrollmentNo?: string | null;
  temporaryPassword: string;
  orgName?: string;
}): Promise<boolean> {
  const roleLabel =
    input.role === 'teacher'
      ? 'Faculty'
      : input.role === 'student'
        ? 'Student'
        : input.role === 'staff'
          ? 'Organization Staff'
          : 'Organization Admin';
  const loginUrl = frontendUrl('/login');
  return sendEmail({
    to: input.to,
    subject: `Your ${roleLabel.toLowerCase()} account on ${env.APP_NAME}`,
    html: userCredentialsMailTemplate({
      firstName: input.firstName,
      roleLabel,
      loginEmail: input.loginEmail,
      enrollmentNo: input.enrollmentNo,
      temporaryPassword: input.temporaryPassword,
      loginUrl,
      orgName: input.orgName,
    }),
    text: [
      `Your ${roleLabel} account is ready.`,
      `Login email: ${input.loginEmail}`,
      input.enrollmentNo ? `Enrollment no: ${input.enrollmentNo}` : null,
      `Password: ${input.temporaryPassword}`,
      `Login: ${loginUrl}`,
    ]
      .filter(Boolean)
      .join('\n'),
  });
}

export async function sendContactFormEmail(input: {
  name: string;
  email: string;
  phone: string;
  message: string;
  subject: string;
  to?: string;
}): Promise<boolean> {
  const to = input.to || env.SMTP_FROM || env.SMTP_USER;
  if (!to) return false;
  return sendEmail({
    to,
    subject: `New contact enquiry: ${input.subject}`,
    html: contactFormMailTemplate(input),
    text: `Name: ${input.name}\nEmail: ${input.email}\nPhone: ${input.phone}\nSubject: ${input.subject}\n\n${input.message}`,
  });
}

const ORG_ACTION_SUBJECT: Record<OrganizationActionType, string> = {
  created: 'Your organization has been registered',
  approved: 'Your organization has been approved',
  updated: 'Your organization details were updated',
  deleted: 'Your organization has been removed',
  deactivated: 'Your organization access is paused',
};

/**
 * Email all org admins (+ contactEmail) when Super Admin acts on the organization.
 */
export async function notifyOrganizationOfSuperAdminAction(input: {
  organizationId: string;
  orgName: string;
  action: OrganizationActionType;
  message: string;
  actorName?: string;
  extraEmails?: string[];
}): Promise<boolean> {
  const emails = new Set(await orgService.getOrganizationNotifyEmails(input.organizationId));
  for (const e of input.extraEmails ?? []) {
    if (e.includes('@')) emails.add(e.toLowerCase().trim());
  }
  if (emails.size === 0) {
    console.warn(
      `[email] No org contacts for ${input.orgName} (${input.organizationId}) — skip ${input.action} mail`,
    );
    return false;
  }

  const to = Array.from(emails);
  return sendEmail({
    to,
    subject: `${env.APP_NAME} — ${ORG_ACTION_SUBJECT[input.action]}`,
    html: organizationActionMailTemplate({
      orgName: input.orgName,
      action: input.action,
      message: input.message,
      actorName: input.actorName,
      actionUrl: frontendUrl('/login'),
    }),
    text: `${ORG_ACTION_SUBJECT[input.action]}: ${input.orgName}\n\n${input.message}`,
  });
}

/** Send login email + temporary password when a new organization is created */
export async function sendOrganizationCredentialsEmail(input: {
  to: string;
  orgName: string;
  adminName?: string;
  loginEmail: string;
  temporaryPassword: string;
  isApproved: boolean;
}): Promise<boolean> {
  const loginUrl = frontendUrl('/login');
  return sendEmail({
    to: input.to,
    subject: `Your ${env.APP_NAME} organization login details`,
    html: organizationCredentialsMailTemplate({
      orgName: input.orgName,
      adminName: input.adminName,
      loginEmail: input.loginEmail,
      temporaryPassword: input.temporaryPassword,
      isApproved: input.isApproved,
      loginUrl,
    }),
    text: [
      `Organization: ${input.orgName}`,
      `Login email: ${input.loginEmail}`,
      `Temporary password: ${input.temporaryPassword}`,
      `Login: ${loginUrl}`,
      input.isApproved
        ? 'Your account is active.'
        : 'Pending Super Admin approval before login.',
    ].join('\n'),
  });
}
